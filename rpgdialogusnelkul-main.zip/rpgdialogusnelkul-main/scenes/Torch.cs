using Godot;
using System;

public partial class Torch : Area2D
{
	public override void _Ready()
	{
		// Feliratkozunk az érintésre
		BodyEntered += OnBodyEntered;
	}

	private void OnBodyEntered(Node2D body)
	{
		// Ellenőrizzük, hogy a Player érintette-e meg
		if (body is Player player)
		{
			// Beállítjuk a változót a játékosnál
			player.ActivateTorch();
			
			// Bekapcsoljuk a fáklya fényét a játékoson (ha van neki)
			// player.GetNode<PointLight2D>("TorchLight").Enabled = true;

			
			
			// Eltüntetjük a fáklyát a földről
			QueueFree();
		}
	}
}
