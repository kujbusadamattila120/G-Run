using Godot;

public partial class IceZone : Area2D
{
	private void _on_body_entered(Node2D body)
	{
		if (body is Player player)
		{
			player.CurrentFriction = 50f; // Nagyon kicsi súrlódás = nagy csúszás!
			GD.Print("Jégen vagy!");
		}
	}

	private void _on_body_exited(Node2D body)
	{
		if (body is Player player)
		{
			player.CurrentFriction = 500f; // Visszaáll a normál tapadás
			GD.Print("Lejöttél a jégről.");
		}
	}
}
