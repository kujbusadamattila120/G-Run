using Godot;
using System;

public partial class Player : CharacterBody2D
{
	// Beállítások az Inspectorban
	[Export] private float MoveSpeed = 200f;
	[Export] private float Acceleration = 1000f;
	[Export] private float Friction = 600f;

	// Node referenciák
	private AnimatedSprite2D _animatedSprite;
	private PointLight2D _torchLight;
	private Area2D _actionableFinder;

	// Játék állapotok
	public bool HasKey = false;
	public bool HasTorch = false;
	public float CurrentFriction;

	public override void _Ready()
	{
		_animatedSprite = GetNode<AnimatedSprite2D>("AnimatedSprite2D");
		_actionableFinder = GetNode<Area2D>("ActionableFinder");
		
		CurrentFriction = Friction;

		// Fontos: Itt a "PointLight2D" névnek egyeznie kell a jelenetfában lévő névvel!
		if (HasNode("PointLight2D"))
		{
			_torchLight = GetNode<PointLight2D>("PointLight2D");
			_torchLight.Enabled = false; // Alapból ki van kapcsolva
		}
	}

	public override void _PhysicsProcess(double delta)
	{
		// 1. DIALÓGUS ELLENŐRZÉSE
		if (GetTree().Root.HasNode("ExampleBalloon"))
		{
			Velocity = Vector2.Zero;
			MoveAndSlide();
			return;
		}

		// 2. MOZGÁS KEZELÉSE
		Vector2 inputDirection = Input.GetVector("ui_left", "ui_right", "ui_up", "ui_down");

		if (inputDirection != Vector2.Zero)
		{
			Velocity = Velocity.MoveToward(inputDirection * MoveSpeed, Acceleration * (float)delta);
			HandleAnimation(inputDirection);
		}
		else
		{
			Velocity = Velocity.MoveToward(Vector2.Zero, CurrentFriction * (float)delta);
			if (Velocity.Length() < 10) _animatedSprite.Stop();
		}

		MoveAndSlide();

		// 3. FÁKLYA VIBRÁLÓ EFFEKT (Tűz hatás)
		if (HasTorch && _torchLight != null)
		{
			// Véletlenszerűen változtatjuk az erejét 0.9 és 1.1 között
			_torchLight.Energy = (float)GD.RandRange(0.9, 1.1);
			
			// Opcionális: kicsit mozgathatjuk is a fényt, mintha lobogna a szélben
			_torchLight.Offset = new Vector2((float)GD.RandRange(-1, 1), (float)GD.RandRange(-1, 1));
		}

		// 4. INTERAKCIÓ
		if (Input.IsActionJustPressed("ui_accept"))
		{
			CheckInteraction();
		}
	}

	// --- EZT A FÜGGVÉNYT HÍVD MEG A TORCH.CS-BŐL ---
	public void ActivateTorch()
	{
		HasTorch = true;
		if (_torchLight != null) 
		{
			_torchLight.Enabled = true;
			GD.Print("Fáklya fénye kigyulladt!");
		}
	}

	private void CheckInteraction()
	{
		if (GetTree().Root.HasNode("ExampleBalloon")) return;

		var areas = _actionableFinder.GetOverlappingAreas();
		foreach (var area in areas)
		{
			if (area.HasMethod("Action"))
			{
				area.Call("Action");
				GD.Print("Interakció indítva: " + area.Name);
				break; 
			}
		}
	}

	private void HandleAnimation(Vector2 direction)
	{
		string anim = "";
		if (Math.Abs(direction.X) > Math.Abs(direction.Y))
			anim = direction.X > 0 ? "walkright" : "walkleft";
		else
			anim = direction.Y > 0 ? "walkdown" : "walkup";

		if (_animatedSprite.Animation != anim) _animatedSprite.Play(anim);
	}

	public void PickupKey()
	{
		HasKey = true;
		GD.Print("Kulcs felvéve!");
	}
}
