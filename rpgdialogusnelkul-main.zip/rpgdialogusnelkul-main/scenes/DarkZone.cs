using Godot;
using System;

public partial class DarkZone : Area2D
{
	// Ezt az Inspectorban kell majd behúznod!
	[Export] private CanvasModulate _canvasModulate;

	// Amikor belépsz a barlangba
	public void _on_body_entered(Node2D body)
	{
		if (body is Player)
		{
			// Létrehozunk egy átmenetet (Tween), ami 1.5 másodperc alatt sötétít be
			var tween = CreateTween();
			// Sötétkék/Fekete színre váltunk
			tween.TweenProperty(_canvasModulate, "color", new Color(0.1f, 0.1f, 0.2f, 1.0f), 1.5f);
		}
	}

	// Amikor kijössz a barlangból
	public void _on_body_exited(Node2D body)
	{
		if (body is Player)
		{
			// Visszaváltunk fehérre (teljes világosság)
			var tween = CreateTween();
			tween.TweenProperty(_canvasModulate, "color", new Color(1, 1, 1, 1), 1.5f);
		}
	}
}
