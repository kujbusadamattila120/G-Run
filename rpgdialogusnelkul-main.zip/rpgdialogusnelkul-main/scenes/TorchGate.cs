using Godot;
using System;

public partial class TorchGate : Area2D
{
	[Export] private StaticBody2D _gateWall; // Húzd be ide a StaticBody2D-t az Inspectorban!

	public override void _Ready()
	{
		// Összekötjük az eseményt: mi történik, ha valaki belelép a zónába
		BodyEntered += OnBodyEntered;
	}

	private void OnBodyEntered(Node2D body)
	{
		if (body is Player player)
		{
			if (player.HasTorch)
			{
				GD.Print("Van nálad fáklya, beléphetsz!");
				OpenGate();
			}
			else
			{
				GD.Print("Túl sötét van bent, fáklya nélkül nem mész sehova!");
				// Itt akár egy rövid dialógust is elindíthatsz
			}
		}
	}

	private void OpenGate()
	{
		// Eltüntetjük a falat, hogy át tudjon menni
		if (_gateWall != null)
		{
			_gateWall.QueueFree(); 
		}
		// A kapu zónáját is kikapcsoljuk, mert már nincs rá szükség
		QueueFree(); 
	}
}
