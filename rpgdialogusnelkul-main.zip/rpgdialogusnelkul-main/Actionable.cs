using Godot;
using System;
// Importáljuk a DialogueManager-t a C# számára
using DialogueManagerRuntime;

public partial class Actionable : Area2D
{
	[Export] public Resource DialogueResource;
	[Export] public string DialogueStart = "start";

	public void Action()
	{
		// A legbiztosabb hívási mód C#-ból:
		DialogueManager.ShowExampleDialogueBalloon(DialogueResource, DialogueStart);
	}
}
