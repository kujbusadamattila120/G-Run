using Godot;
using System;

public partial class Sign : Area2D
{
	[Export] public Resource DialogueResource;
	[Export] public string DialogueStartNode = "start";

	public void Action()
	{
		GD.Print("Interakció a táblával megtörtént!");

		if (DialogueResource != null)
		{
			// Megpróbáljuk lekérni a DialogueManager Autoload-ot
			var dialogueManager = GetNode("/root/DialogueManager");
			
			if (dialogueManager != null)
			{
				// A Godot 4 C# esetében a Variant-ok kezelése miatt így a legbiztosabb hívni:
				dialogueManager.Call("show_example_balloon", DialogueResource, DialogueStartNode);
			}
			else
			{
				GD.Print("HIBA: A DialogueManager nincs beállítva az Autoload-ban!");
			}
		}
		else
		{
			GD.Print("HIBA: Nincs behúzva a .dialogue fájl az Inspectorban!");
		}
	}
}
